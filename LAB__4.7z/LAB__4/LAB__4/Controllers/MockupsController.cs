﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using LAB__4.Models;
using Microsoft.AspNetCore.Mvc.ModelBinding;

namespace LAB__4.Controllers
{
    public class MockupsController : Controller
    {
        Random rnd = new Random();

        public IActionResult Index()
        {
            return View();
        }
        [AcceptVerbs("GET", "POST")]
        public IActionResult CheckEmail(string email)
        {
            if (IdentityMap.Get().ContainsKey(email))
                return Json(false);
            return Json(true);
        }
        [HttpGet]
        public IActionResult SignUp()
        {
            return View();
        }
        [HttpPost]
        public IActionResult SignUp(NewModel model)
        {
            if (ModelState["FirstName"].ValidationState == ModelValidationState.Valid &
                ModelState["LastName"].ValidationState == ModelValidationState.Valid &
                ModelState["Gender"].ValidationState == ModelValidationState.Valid)
                return RedirectToAction("SignUp2", model);
            return View();
        }
        [HttpGet]
        public IActionResult SignUp2()
        {
            return View();
        }
        [HttpPost]
        public IActionResult SignUp2(NewModel model)
        {

            if (ModelState["Email"].ValidationState == ModelValidationState.Valid &
                ModelState["Password"].ValidationState == ModelValidationState.Valid &
                ModelState["ConfirmPassword"].ValidationState == ModelValidationState.Valid)
            {
                if (IdentityMap.Get().ContainsKey(model.Email)) return View(model);
                IdentityMap.Get().Add(model.Email, model);
                return View("Result", model);
            }
            return View();
        }
        [HttpGet]
        public IActionResult Reset2()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Reset2(NewModel model, string myTextbox)
        {

            if (model.Code == myTextbox)
            {
                return RedirectToAction("Reset3", model);
            }
            ViewBag.Check = "Wrong code";
            return View(model);
        }
        [HttpGet]
        public IActionResult Reset3()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Reset3(NewModel model)
        {

            if (ModelState["Password"].ValidationState == ModelValidationState.Valid &
                ModelState["ConfirmPassword"].ValidationState == ModelValidationState.Valid)
                return View("Result2");
            else View(model);

            return View();
        }
        [HttpGet]
        public IActionResult Reset()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Reset(string Email, string action)
        {
            NewModel model;
            if (Email == null)
            {
                ViewBag.Code = "Вы не ввели email";
                return View();
            }
            if (IdentityMap.Get().TryGetValue(Email, out model))
            {
                if (action == "Send me a code")
                {
                    string b = Convert.ToString(rnd.Next(0, 10)) + Convert.ToString(rnd.Next(0, 10)) + Convert.ToString(rnd.Next(0, 10)) + Convert.ToString(rnd.Next(0, 10));
                    ViewBag.Code = b;
                    IdentityMap.Get()[Email].Code = b;
                    return View();
                }
                else return RedirectToAction("Reset2", model);
            }
            ViewBag.Code = "Вы не зарегистрированы";
            return View();
        }
    }
}
